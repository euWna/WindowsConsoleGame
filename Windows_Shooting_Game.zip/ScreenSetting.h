#pragma once
#ifndef __SCREEN_SETTING_H__
#define __SCREEN_SETTING_H__

#define dfSCREEN_WIDTH		81		// �ܼ� ���� 80ĭ + NULL
#define dfSCREEN_HEIGHT		24		// �ܼ� ���� 24ĭ

const int SCREEN_SIZE = dfSCREEN_WIDTH * dfSCREEN_HEIGHT;

#endif